<?php
session_start();
error_reporting(E_ALL ^ E_WARNING); 
$line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
file_put_contents('logs/visitors.log', $line . PHP_EOL, FILE_APPEND);
if (isset($_POST['Submit']) == 'Send')
{
// if (strcmp(md5($_POST['user_code']),$_SESSION['ckey']))
// 	{ 
// header("Location: sendmail.php?msg=ERROR: Invalid Verification Code");
// exit();
//   } 

$to = $_POST['toemail'];
$cc = $_POST['cc'];
$bcc = $_POST['bcc'];
$subject = $_POST['subject'];
$message = $_POST['message'];
$fromemail = $_POST['fromemail'];
$fromname = $_POST['fromname'];
$replyto = $_POST['replyto'];
$lt= '<';
$gt= '>';
$sp= ' ';
$from= 'From:';

$headers = [
  'MIME-Version: 1.0',
  'Content-type: text/html; charset=utf-8',
  'From: '.$fromname.' <'.$fromemail.'>',
  'Cc: '.$cc,
  'Bcc: '.$bcc,
  'Reply-To: '.$replyto,
];
$headers = implode("\r\n", $headers);

file_put_contents('logs/requests.log', $headers . " " . $to . " " . $subject . " " . $message . " " . $line . PHP_EOL, FILE_APPEND);
mail($to,$subject,$message,$headers);

// $sent = mail($to, $subject, $message, $headers);
// echo $sent ? "Mail send OK" : "Mail send ERROR" ;

header("Location: sendmail.php?msg= Mail Sent!");
exit();
}
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="mystyle.css">
<title>Email Pranks</title>
</head>
<body bgcolor="#f0f0f0">
<div class="center-div">
<h2 align="center">
<img src="uchiha.png" alt="Italian Trulli" style="width:1000px;height:150px">
Fake Email Prank Script By Itachi Uchiha
</h2>
<h3 align="center">
Please do not misuse this script. Use it only for having FUN.
</h3>
<p style="margin-left:15px">
<form action="sendmail.php" method="POST">
<b>From Name</b>
<input type="text" name="fromname" size="25"><br>
<br><b>From Email</b>
<input type="text" name="fromemail" size="25"><br>
<br><b>To Email &emsp;</b>
<input type="text" name="toemail" size="25"><br>
<br><b>Cc Email &emsp;</b>
<input type="text" name="cc" size="25"><br>
<br><b>bccEmail &emsp;</b>
<input type="text" name="bcc" size="25"><br>
<br><b>ReplyTo &emsp;</b>
<input type="text" name="replyto" size="25"><br>
<br><b>Subject &emsp;&ensp;</b>
<input type="text" name="subject" size="25"><br>
<br><b>Your Message</b><br>
<textarea name="message" rows="5" cols="50">
</textarea><br>
<br><b>Verification Code:</b><br>
<input name="user_code" type="text" size="25">  
<img src="pngimg.php" align="middle"><br><br>
<input type="submit" name="Submit" value="Send">
<input type="reset" value="Reset">
</form>
</p>
<?php if (isset($_GET['msg'])) { echo "<font color=\"red\"><h3 align=\"center\"> $_GET[msg] </h3></font>"; } ?>
<h3 align="center">
WARNING: Use it at your own risk. Do not use this for Spamming!.
</h3>
<img src="itachi.jpg" alt="Italian Trulli" style="width:1000px;height:300px">
</div>
</body>
</html>

